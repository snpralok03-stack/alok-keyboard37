ALOK KEYBOARD ULTIMATE — SOURCE PROJECT

This is a native Android InputMethodService project based on the Alok Keyboard source project.

CURRENTLY IMPLEMENTED IN THIS SOURCE:
- Dark QWERTY keyboard with number row
- Shift, backspace, enter, symbols and emoji keyboard mode
- English/Hinglish mode toggle
- Five text transformations: MONO, BANANA, ALTERNATE, REVERSE, CHIPKU
- Live transformation previews
- Basic offline word suggestions (small built-in word list)
- Contextual emoji suggestion row
- Setup screen and IME registration

NOT YET IMPLEMENTED / NOT GBOARD-EQUIVALENT:
- Full autocorrect and large predictive language model
- Voice dictation flow integrated into the IME
- Clipboard history manager
- Online GIF search/provider integration
- True swipe/gesture typing engine
- Full multi-language dictionaries and personalized learning
- Full light/dark theme settings

IMPORTANT:
This is a source project, not a verified APK. Android SDK/Gradle build and real-device testing have not been run in this environment. Do not treat unimplemented items as working. Build with Android Studio/AndroidIDE and test each feature before daily use.

Build:
1. Open the alok_fix folder in Android Studio or a compatible Android IDE.
2. Sync Gradle.
3. Build > Build APK(s), or run ./gradlew assembleDebug.
4. Enable Alok Keyboard in Android Settings > System > Keyboard > On-screen keyboard.
