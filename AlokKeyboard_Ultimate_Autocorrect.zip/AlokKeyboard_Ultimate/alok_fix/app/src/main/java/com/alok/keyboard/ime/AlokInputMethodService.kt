package com.alok.keyboard.ime

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import com.alok.keyboard.R
import com.alok.keyboard.transform.TextTransformer
import com.alok.keyboard.transform.TransformType

class AlokInputMethodService : InputMethodService(), AlokKeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: AlokKeyboardView

    private lateinit var btnMono: LinearLayout
    private lateinit var btnBanana: LinearLayout
    private lateinit var btnAlternate: LinearLayout
    private lateinit var btnReverse: LinearLayout
    private lateinit var btnChipku: LinearLayout

    private lateinit var previewMono: TextView
    private lateinit var previewBanana: TextView
    private lateinit var previewAlternate: TextView
    private lateinit var previewReverse: TextView
    private lateinit var previewChipku: TextView
    private lateinit var wordSuggestions: LinearLayout
    private lateinit var emojiSuggestions: LinearLayout

    private val commonWords = listOf(
        "hello", "help", "hey", "how", "hii", "hi", "good", "great", "going",
        "thanks", "thank", "the", "this", "that", "there", "you", "your",
        "are", "and", "about", "awesome", "bro", "love", "please", "what",
        "when", "where", "why", "yes", "no", "okay", "ok", "india", "alok"
    )

    override fun onCreateInputView(): View {
        val root = layoutInflater.inflate(R.layout.keyboard_container, null)

        keyboardView = root.findViewById(R.id.alok_keyboard_view)
        keyboardView.listener = this

        btnMono = root.findViewById(R.id.btn_transform_mono)
        btnBanana = root.findViewById(R.id.btn_transform_banana)
        btnAlternate = root.findViewById(R.id.btn_transform_alternate)
        btnReverse = root.findViewById(R.id.btn_transform_reverse)
        btnChipku = root.findViewById(R.id.btn_transform_chipku)

        previewMono = root.findViewById(R.id.preview_mono)
        previewBanana = root.findViewById(R.id.preview_banana)
        previewAlternate = root.findViewById(R.id.preview_alternate)
        previewReverse = root.findViewById(R.id.preview_reverse)
        previewChipku = root.findViewById(R.id.preview_chipku)
        wordSuggestions = root.findViewById(R.id.word_suggestions)
        emojiSuggestions = root.findViewById(R.id.emoji_suggestions)

        btnMono.setOnClickListener { applyTransformation(TransformType.MONO) }
        btnBanana.setOnClickListener { applyTransformation(TransformType.BANANA) }
        btnAlternate.setOnClickListener { applyTransformation(TransformType.ALTERNATE) }
        btnReverse.setOnClickListener { applyTransformation(TransformType.REVERSE) }
        btnChipku.setOnClickListener { applyTransformation(TransformType.CHIPKU) }

        updateLivePreviews()
        updateSuggestions()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        updateLivePreviews()
        updateSuggestions()
    }

    override fun onUpdateSelection(
        oldSelStart: Int,
        oldSelEnd: Int,
        newSelStart: Int,
        newSelEnd: Int,
        candidatesStart: Int,
        candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart,
            oldSelEnd,
            newSelStart,
            newSelEnd,
            candidatesStart,
            candidatesEnd
        )
        updateLivePreviews()
        updateSuggestions()
    }

    /**
     * Reads the currently typed word before the cursor without altering editor state.
     */
    private fun getCurrentTypedWord(): String {
        val ic: InputConnection = currentInputConnection ?: return ""
        val before = ic.getTextBeforeCursor(64, 0) ?: return ""
        return TextTransformer.extractCurrentWordBeforeCursor(before)
    }

    /**
     * Updates the live transformation previews inside all 5 buttons instantly as the user types.
     */
    private fun updateLivePreviews() {
        if (!::previewMono.isInitialized) return

        val currentWord = getCurrentTypedWord()
        val sample = currentWord.ifEmpty { "alok" }

        previewMono.text = TextTransformer.transform(sample, TransformType.MONO)
        previewBanana.text = TextTransformer.transform(sample, TransformType.BANANA)
        previewAlternate.text = TextTransformer.transform(sample, TransformType.ALTERNATE)
        previewReverse.text = TextTransformer.transform(sample, TransformType.REVERSE)
        previewChipku.text = TextTransformer.transform(sample, TransformType.CHIPKU)

        val alpha = if (currentWord.isNotEmpty()) 1.0f else 0.72f
        btnMono.alpha = alpha
        btnBanana.alpha = alpha
        btnAlternate.alpha = alpha
        btnReverse.alpha = alpha
        btnChipku.alpha = alpha
    }

    private fun updateSuggestions() {
        if (!::wordSuggestions.isInitialized || !::emojiSuggestions.isInitialized) return
        val word = getCurrentTypedWord().lowercase()
        wordSuggestions.removeAllViews()
        val predictions = if (word.isBlank()) {
            listOf("the", "you", "hello")
        } else {
            commonWords.filter { it.startsWith(word) && it != word }.take(3)
                .ifEmpty { listOf(word).filter { it.isNotBlank() } }
        }
        predictions.take(3).forEach { candidate ->
            wordSuggestions.addView(makeSuggestion(candidate) {
                val ic = currentInputConnection
                if (ic != null) {
                    val typed = getCurrentTypedWord()
                    ic.beginBatchEdit()
                    try {
                        if (typed.isNotEmpty()) ic.deleteSurroundingText(typed.length, 0)
                        ic.commitText(candidate, 1)
                    } finally { ic.endBatchEdit() }
                    updateLivePreviews()
                    updateSuggestions()
                }
            })
        }

        emojiSuggestions.removeAllViews()
        val emojis = when {
            word.contains("love") || word.contains("pyar") -> listOf("❤️", "🥰", "😍", "😘", "💕")
            word.contains("happy") || word.contains("good") || word.contains("great") -> listOf("😊", "😄", "🔥", "👏", "✨")
            word.contains("sad") || word.contains("sorry") -> listOf("🥺", "😔", "💔", "🤗", "❤️")
            word.contains("hello") || word == "hi" || word == "hey" -> listOf("👋", "😊", "❤️", "😂", "😎")
            word.contains("laugh") || word.contains("lol") || word.contains("haha") -> listOf("😂", "🤣", "😭", "😆", "💀")
            else -> listOf("😂", "❤️", "🔥", "😊", "😎")
        }
        emojis.forEach { emoji ->
            emojiSuggestions.addView(makeSuggestion(emoji) {
                currentInputConnection?.commitText(emoji, 1)
                updateLivePreviews()
                updateSuggestions()
            })
        }
    }

    private fun makeSuggestion(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = if (label.length <= 2 && label.any { it.code > 127 }) 19f else 14f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER
            setPadding(12, 0, 12, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }
    }

    /**
     * Atomically replaces the currently typed word before the cursor with the transformed text,
     * keeping cursor position at the exact end of the replaced word without duplicate characters
     * or accidental trailing spaces.
     */
    private fun applyTransformation(type: TransformType) {
        val ic: InputConnection = currentInputConnection ?: return
        // Prefer an explicitly selected word; otherwise transform the word before the cursor.
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val currentWord = if (selected.isNotEmpty()) selected else getCurrentTypedWord()
        if (currentWord.isEmpty()) return

        val transformed = TextTransformer.transform(currentWord, type)
        if (transformed == currentWord) return

        performHapticFeedback()

        ic.beginBatchEdit()
        try {
            if (selected.isNotEmpty()) {
                // commitText replaces the active selection and places the cursor after the result.
                ic.commitText(transformed, 1)
            } else {
                // Replace exactly the active word immediately before the cursor.
                ic.deleteSurroundingText(currentWord.length, 0)
                ic.commitText(transformed, 1)
            }
        } finally {
            ic.endBatchEdit()
        }

        updateLivePreviews()
        updateSuggestions()
    }

    override fun onCharacterKey(text: String) {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        ic.commitText(text, 1)
        updateLivePreviews()
        updateSuggestions()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        val selectedText = ic.getSelectedText(0)
        if (!selectedText.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
        updateLivePreviews()
        updateSuggestions()
    }

    private var lastSpaceAt: Long = 0L

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        val now = android.os.SystemClock.uptimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()

        // Double-space shortcut: turn the just-entered space into a period + space.
        if (now - lastSpaceAt < 450L && before.endsWith(" ")) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            lastSpaceAt = 0L
        } else {
            val typedWord = getCurrentTypedWord()
            val corrected = AutoCorrector.correct(typedWord)
            if (typedWord.isNotEmpty() && corrected != typedWord) {
                ic.beginBatchEdit()
                try {
                    ic.deleteSurroundingText(typedWord.length, 0)
                    ic.commitText(corrected + " ", 1)
                } finally {
                    ic.endBatchEdit()
                }
            } else {
                ic.commitText(" ", 1)
            }
            lastSpaceAt = now
        }
        updateLivePreviews()
        updateSuggestions()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        val editorInfo = currentInputEditorInfo
        val action = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE

        if (action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED &&
            (editorInfo.inputType and EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE) == 0
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateLivePreviews()
    }

    override fun onShiftToggle() {
        performHapticFeedback()
    }

    override fun onSwitchSymbols() {
        performHapticFeedback()
    }

    override fun onSwitchEmoji() {
        performHapticFeedback()
    }

    override fun onSwitchLanguage() {
        performHapticFeedback()
        updateLivePreviews()
    }

    private fun performHapticFeedback() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val mgr = getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                mgr?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
            // Safe fallback on devices without vibrator permission/hardware
        }
    }
}
