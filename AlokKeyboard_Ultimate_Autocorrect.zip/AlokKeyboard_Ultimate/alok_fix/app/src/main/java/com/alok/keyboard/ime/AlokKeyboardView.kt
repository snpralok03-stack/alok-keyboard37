package com.alok.keyboard.ime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class AlokKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface OnKeyboardActionListener {
        fun onCharacterKey(text: String)
        fun onBackspace()
        fun onEnter()
        fun onSpace()
        fun onShiftToggle()
        fun onSwitchSymbols()
        fun onSwitchEmoji()
        fun onSwitchLanguage()
    }

    enum class KeyboardMode {
        QWERTY,
        SYMBOLS,
        EMOJI
    }

    enum class ShiftState {
        OFF,
        ON,
        CAPS_LOCK
    }

    var listener: OnKeyboardActionListener? = null
    var mode: KeyboardMode = KeyboardMode.QWERTY
        set(value) {
            field = value
            rebuildKeys()
            invalidate()
        }

    var shiftState: ShiftState = ShiftState.OFF
        set(value) {
            field = value
            invalidate()
        }

    var isHinglishMode: Boolean = false
        set(value) {
            field = value
            rebuildKeys()
            invalidate()
        }

    private data class Key(
        val code: Int,
        val label: String,
        val altLabel: String? = null,
        val weight: Float = 1f,
        val isFunctional: Boolean = false,
        val isPrimaryAction: Boolean = false,
        val bounds: RectF = RectF()
    )

    companion object {
        const val KEY_CHAR = 1
        const val KEY_SHIFT = -1
        const val KEY_BACKSPACE = -5
        const val KEY_SYMBOLS = -2
        const val KEY_EMOJI = -10
        const val KEY_LANG = -11
        const val KEY_SPACE = 32
        const val KEY_ENTER = 10
    }

    private var rows: List<List<Key>> = emptyList()
    private var pressedKey: Key? = null
    private var lastShiftClickTime: Long = 0L

    private val repeatHandler = Handler(Looper.getMainLooper())
    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (pressedKey?.code == KEY_BACKSPACE) {
                listener?.onBackspace()
                repeatHandler.postDelayed(this, 55L)
            }
        }
    }

    // Dark theme paints matching existing keyboard design
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#121316")
    }
    private val normalKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#25282E")
    }
    private val functionalKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1C1E23")
    }
    private val pressedKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3B404A")
    }
    private val activeShiftPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3E63DD")
    }
    private val enterKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E6BE6")
    }
    private val keyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F3F4F6")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
    private val functionalTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D1D5DB")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    init {
        rebuildKeys()
    }

    private fun rebuildKeys() {
        rows = when (mode) {
            KeyboardMode.QWERTY -> buildQwertyRows()
            KeyboardMode.SYMBOLS -> buildSymbolRows()
            KeyboardMode.EMOJI -> buildEmojiRows()
        }
        requestLayout()
    }

    private fun buildQwertyRows(): List<List<Key>> {
        val numberRow = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
            .map { Key(KEY_CHAR, it) }

        val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
            .map { Key(KEY_CHAR, it) }

        val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
            .map { Key(KEY_CHAR, it) }

        val row3 = buildList {
            add(Key(KEY_SHIFT, "⇧", weight = 1.45f, isFunctional = true))
            listOf("z", "x", "c", "v", "b", "n", "m").forEach {
                add(Key(KEY_CHAR, it))
            }
            add(Key(KEY_BACKSPACE, "⌫", weight = 1.45f, isFunctional = true))
        }

        val spaceLabel = if (isHinglishMode) "Hinglish" else "English"
        val row4 = listOf(
            Key(KEY_SYMBOLS, "?123", weight = 1.3f, isFunctional = true),
            Key(KEY_EMOJI, "😊", weight = 1.15f, isFunctional = true),
            Key(KEY_LANG, "🌐", weight = 1.15f, isFunctional = true),
            Key(KEY_SPACE, spaceLabel, weight = 3.9f),
            Key(KEY_CHAR, ".", weight = 1.0f),
            Key(KEY_ENTER, "↵", weight = 1.5f, isFunctional = true, isPrimaryAction = true)
        )

        return listOf(numberRow, row1, row2, row3, row4)
    }

    private fun buildSymbolRows(): List<List<Key>> {
        val row0 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
            .map { Key(KEY_CHAR, it) }
        val row1 = listOf("@", "#", "$", "_", "&", "-", "+", "(", ")", "/")
            .map { Key(KEY_CHAR, it) }
        val row2 = listOf("*", "\"", "'", ":", ";", "!", "?", "~", "`")
            .map { Key(KEY_CHAR, it) }
        val row3 = buildList {
            add(Key(KEY_SYMBOLS, "ABC", weight = 1.45f, isFunctional = true))
            listOf("%", "=", "{", "}", "[", "]", "\\").forEach {
                add(Key(KEY_CHAR, it))
            }
            add(Key(KEY_BACKSPACE, "⌫", weight = 1.45f, isFunctional = true))
        }
        val row4 = listOf(
            Key(KEY_SYMBOLS, "ABC", weight = 1.3f, isFunctional = true),
            Key(KEY_EMOJI, "😊", weight = 1.15f, isFunctional = true),
            Key(KEY_CHAR, ",", weight = 1.15f),
            Key(KEY_SPACE, "Space", weight = 3.9f),
            Key(KEY_CHAR, ".", weight = 1.0f),
            Key(KEY_ENTER, "↵", weight = 1.5f, isFunctional = true, isPrimaryAction = true)
        )
        return listOf(row0, row1, row2, row3, row4)
    }

    private fun buildEmojiRows(): List<List<Key>> {
        val row0 = listOf("😀", "😂", "🥰", "😎", "🤩", "😭", "😡", "🙏", "👍", "🔥")
            .map { Key(KEY_CHAR, it) }
        val row1 = listOf("❤️", "💯", "✨", "🎉", "🤝", "👌", "🙌", "🥳", "🤔", "😴")
            .map { Key(KEY_CHAR, it) }
        val row2 = listOf("🇮🇳", "🏏", "☕", "🎶", "🚀", "💡", "⚡", "🌟", "💪")
            .map { Key(KEY_CHAR, it) }
        val row3 = buildList {
            add(Key(KEY_SYMBOLS, "ABC", weight = 1.45f, isFunctional = true))
            listOf("😅", "😇", "😉", "😍", "🤗", "😜", "🫡").forEach {
                add(Key(KEY_CHAR, it))
            }
            add(Key(KEY_BACKSPACE, "⌫", weight = 1.45f, isFunctional = true))
        }
        val row4 = listOf(
            Key(KEY_SYMBOLS, "ABC", weight = 1.3f, isFunctional = true),
            Key(KEY_EMOJI, "⌨", weight = 1.15f, isFunctional = true),
            Key(KEY_LANG, "🌐", weight = 1.15f, isFunctional = true),
            Key(KEY_SPACE, "Space", weight = 3.9f),
            Key(KEY_CHAR, ".", weight = 1.0f),
            Key(KEY_ENTER, "↵", weight = 1.5f, isFunctional = true, isPrimaryAction = true)
        )
        return listOf(row0, row1, row2, row3, row4)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val density = resources.displayMetrics.density
        val rowHeight = (46f * density).toInt()
        val verticalPadding = (8f * density).toInt()
        val totalHeight = (rows.size * rowHeight) + verticalPadding
        setMeasuredDimension(width, totalHeight)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys(w.toFloat(), h.toFloat())
    }

    private fun layoutKeys(totalWidth: Float, totalHeight: Float) {
        if (rows.isEmpty() || totalWidth <= 0f || totalHeight <= 0f) return
        val density = resources.displayMetrics.density
        val hGap = 4.5f * density
        val vGap = 6f * density
        val sidePad = 4f * density
        val topPad = 4f * density
        val bottomPad = 4f * density

        val usableHeight = totalHeight - topPad - bottomPad
        val rowHeight = (usableHeight - vGap * (rows.size - 1)) / rows.size

        rows.forEachIndexed { rowIndex, rowKeys ->
            val totalWeight = rowKeys.sumOf { it.weight.toDouble() }.toFloat()
            val rowTop = topPad + rowIndex * (rowHeight + vGap)
            val rowBottom = rowTop + rowHeight

            // Slightly inset row 2 (A-L) like standard Android QWERTY
            val isMiddleAlphaRow = (mode == KeyboardMode.QWERTY && rowIndex == 2)
            val extraInset = if (isMiddleAlphaRow) totalWidth * 0.045f else 0f
            val rowUsableWidth = totalWidth - (sidePad * 2) - (extraInset * 2) - (hGap * (rowKeys.size - 1))

            var currentX = sidePad + extraInset
            for (key in rowKeys) {
                val keyWidth = rowUsableWidth * (key.weight / totalWeight)
                key.bounds.set(currentX, rowTop, currentX + keyWidth, rowBottom)
                currentX += keyWidth + hGap
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val density = resources.displayMetrics.density
        val cornerRadius = 6f * density

        for (row in rows) {
            for (key in row) {
                val isPressed = (key === pressedKey)
                val paint = when {
                    isPressed -> pressedKeyPaint
                    key.isPrimaryAction -> enterKeyPaint
                    key.code == KEY_SHIFT && shiftState != ShiftState.OFF -> activeShiftPaint
                    key.isFunctional -> functionalKeyPaint
                    else -> normalKeyPaint
                }

                canvas.drawRoundRect(key.bounds, cornerRadius, cornerRadius, paint)

                val displayLabel = getDisplayLabel(key)
                val activeTextPaint = if (key.isFunctional || key.code == KEY_SPACE) {
                    functionalTextPaint
                } else {
                    keyTextPaint
                }

                activeTextPaint.textSize = when {
                    key.code == KEY_SPACE -> 13.5f * density
                    key.label.length > 2 -> 13f * density
                    else -> 19f * density
                }

                val textX = key.bounds.centerX()
                val textY = key.bounds.centerY() - ((activeTextPaint.descent() + activeTextPaint.ascent()) / 2f)
                canvas.drawText(displayLabel, textX, textY, activeTextPaint)
            }
        }
    }

    private fun getDisplayLabel(key: Key): String {
        if (key.code == KEY_SHIFT) {
            return when (shiftState) {
                ShiftState.OFF -> "⇧"
                ShiftState.ON -> "⬆"
                ShiftState.CAPS_LOCK -> "⇪"
            }
        }
        if (key.code == KEY_CHAR && key.label.length == 1 && key.label[0].isLetter()) {
            return if (shiftState != ShiftState.OFF) {
                key.label.uppercase()
            } else {
                key.label.lowercase()
            }
        }
        return key.label
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = findKeyAt(x, y)
                pressedKey = hit
                invalidate()
                if (hit?.code == KEY_BACKSPACE) {
                    listener?.onBackspace()
                    repeatHandler.removeCallbacks(backspaceRunnable)
                    repeatHandler.postDelayed(backspaceRunnable, 320L)
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val hit = findKeyAt(x, y)
                if (hit !== pressedKey) {
                    if (pressedKey?.code == KEY_BACKSPACE) {
                        repeatHandler.removeCallbacks(backspaceRunnable)
                    }
                    pressedKey = hit
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                repeatHandler.removeCallbacks(backspaceRunnable)
                val hit = pressedKey
                pressedKey = null
                invalidate()
                if (hit != null && hit.code != KEY_BACKSPACE) {
                    dispatchKeyPress(hit)
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                repeatHandler.removeCallbacks(backspaceRunnable)
                pressedKey = null
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun findKeyAt(x: Float, y: Float): Key? {
        for (row in rows) {
            for (key in row) {
                if (key.bounds.contains(x, y)) {
                    return key
                }
            }
        }
        return null
    }

    private fun dispatchKeyPress(key: Key) {
        when (key.code) {
            KEY_SHIFT -> {
                val now = System.currentTimeMillis()
                shiftState = when {
                    shiftState == ShiftState.CAPS_LOCK -> ShiftState.OFF
                    shiftState == ShiftState.ON && (now - lastShiftClickTime) < 350L -> ShiftState.CAPS_LOCK
                    shiftState == ShiftState.ON -> ShiftState.OFF
                    else -> ShiftState.ON
                }
                lastShiftClickTime = now
                listener?.onShiftToggle()
            }

            KEY_SYMBOLS -> {
                mode = if (mode == KeyboardMode.QWERTY) KeyboardMode.SYMBOLS else KeyboardMode.QWERTY
                listener?.onSwitchSymbols()
            }

            KEY_EMOJI -> {
                mode = if (mode == KeyboardMode.EMOJI) KeyboardMode.QWERTY else KeyboardMode.EMOJI
                listener?.onSwitchEmoji()
            }

            KEY_LANG -> {
                isHinglishMode = !isHinglishMode
                listener?.onSwitchLanguage()
            }

            KEY_SPACE -> {
                listener?.onSpace()
            }

            KEY_ENTER -> {
                listener?.onEnter()
            }

            KEY_CHAR -> {
                val output = getDisplayLabel(key)
                listener?.onCharacterKey(output)
                if (shiftState == ShiftState.ON && output.length == 1 && output[0].isLetter()) {
                    shiftState = ShiftState.OFF
                }
            }
        }
    }
}
