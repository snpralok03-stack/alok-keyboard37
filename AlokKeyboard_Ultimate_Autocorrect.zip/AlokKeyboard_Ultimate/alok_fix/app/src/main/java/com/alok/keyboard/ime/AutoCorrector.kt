package com.alok.keyboard.ime

/** Lightweight offline typo correction for frequent English typing mistakes. */
object AutoCorrector {
    private val corrections = mapOf(
        "teh" to "the", "thier" to "their", "recieve" to "receive",
        "adress" to "address", "becuase" to "because", " definately" to " definitely",
        "definately" to "definitely", "seperate" to "separate", " occured" to "occurred",
        "occured" to "occurred", "untill" to "until", "wierd" to "weird",
        "freind" to "friend", "langauge" to "language", "beleive" to "believe",
        " goverment" to "government", "goverment" to "government",
        " thier" to " their", " dont" to " don't", " cant" to " can't",
        "wont" to "won't", "doesnt" to "doesn't", "didnt" to "didn't",
        "im" to "I'm", "ive" to "I've", "ill" to "I'll", "youre" to "you're",
        "thats" to "that's", "whats" to "what's", "isnt" to "isn't",
        "arent" to "aren't", "wasnt" to "wasn't", "werent" to "weren't",
        "helo" to "hello", "helllo" to "hello", "hllo" to "hello",
        "goood" to "good", "thnaks" to "thanks", "tahnks" to "thanks",
        "pleae" to "please", "plese" to "please", "becuse" to "because"
    )

    fun correct(word: String): String {
        if (word.isBlank() || word.any { !it.isLetter() && it != '\'' }) return word
        val replacement = corrections[word.lowercase()] ?: return word
        return when {
            word.all { !it.isLetter() || it.isUpperCase() } -> replacement.uppercase()
            word.firstOrNull()?.isUpperCase() == true -> replacement.replaceFirstChar { it.uppercase() }
            else -> replacement
        }
    }
}
